If cannot run the two jars directly, Please run it in cmd. And also make sure you use jre1.7.


1. java -jar Exporter.jar


2. java -jar Importer.jar