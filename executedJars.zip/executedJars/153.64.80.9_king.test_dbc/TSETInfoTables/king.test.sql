create table "king.test".test3(t3 integer);
create table "king.test".test4(t4 varchar(10));
create table "test2.test2"("t2.t2" integer);
create view testView as select t1 from test1;
